import React from 'react';
import { Github, Linkedin, Mail, BookOpen, Video, Hash } from 'lucide-react';
import { SocialLink } from './SocialLink';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-5xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dr. John Doe</h1>
            <p className="mt-1 text-lg text-gray-600">AI Researcher & Computer Science Professor</p>
          </div>
          <div className="flex gap-4 mt-4 md:mt-0">
            <SocialLink href="https://github.com" icon={Github} label="GitHub" />
            <SocialLink href="https://linkedin.com" icon={Linkedin} label="LinkedIn" />
            <SocialLink href="mailto:john.doe@university.edu" icon={Mail} label="Email" />
            <div className="w-px h-5 bg-gray-300 mx-2 self-center" />
            <SocialLink href="https://www.xiaohongshu.com" icon={BookOpen} label="小红书" />
            <SocialLink href="https://space.bilibili.com" icon={Video} label="哔哩哔哩" />
            <SocialLink href="https://www.shipinhao.com" icon={Hash} label="视频号" />
          </div>
        </div>
      </div>
    </header>
  );
}