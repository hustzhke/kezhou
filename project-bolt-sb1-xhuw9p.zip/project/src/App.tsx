import React from 'react';
import { ExternalLink, Bookmark, GraduationCap, Book, Award, TestTube } from 'lucide-react';
import { Header } from './components/Header';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <Header />

      <main className="max-w-5xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Education */}
            <section className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <GraduationCap className="w-6 h-6 text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">Education</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900">Ph.D. in Computer Science</h3>
                  <p className="text-gray-600">Stanford University, 2018-2022</p>
                  <p className="text-sm text-gray-500">Thesis: "Advanced Applications of Neural Networks in Natural Language Processing"</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">M.S. in Artificial Intelligence</h3>
                  <p className="text-gray-600">MIT, 2016-2018</p>
                </div>
              </div>
            </section>

            {/* Publications */}
            <section className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <Book className="w-6 h-6 text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">Selected Publications</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900">"Deep Learning Approaches to Natural Language Understanding"</h3>
                  <p className="text-gray-600">Nature AI, 2023</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">"Transformer Architecture Improvements for Large Language Models"</h3>
                  <p className="text-gray-600">ICML 2022</p>
                </div>
              </div>
            </section>

            {/* Research Experience */}
            <section className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <TestTube className="w-6 h-6 text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">Research Experience</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900">Lead AI Researcher</h3>
                  <p className="text-gray-600">Google AI, 2022-Present</p>
                  <p className="text-sm text-gray-500">Leading research in large language models and their applications</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Research Assistant</h3>
                  <p className="text-gray-600">Stanford AI Lab, 2018-2022</p>
                </div>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* AI Tools */}
            <section className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <Bookmark className="w-6 h-6 text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">AI Tools Collection</h2>
              </div>
              <div className="space-y-3">
                {[
                  {
                    name: "ChatGPT",
                    description: "Advanced language model for conversation and text generation",
                    url: "https://chat.openai.com"
                  },
                  {
                    name: "Hugging Face",
                    description: "Repository of machine learning models and datasets",
                    url: "https://huggingface.co"
                  },
                  {
                    name: "Google Colab",
                    description: "Free cloud service for machine learning development",
                    url: "https://colab.research.google.com"
                  },
                  {
                    name: "TensorFlow Hub",
                    description: "Library of reusable machine learning models",
                    url: "https://tfhub.dev"
                  },
                  {
                    name: "Papers with Code",
                    description: "Collection of machine learning papers with implementations",
                    url: "https://paperswithcode.com"
                  }
                ].map((tool, index) => (
                  <div key={index} className="group">
                    <a
                      href={tool.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block p-3 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-gray-900 group-hover:text-indigo-600">{tool.name}</h3>
                        <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-indigo-600" />
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{tool.description}</p>
                    </a>
                  </div>
                ))}
              </div>
            </section>

            {/* Awards */}
            <section className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <Award className="w-6 h-6 text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">Awards</h2>
              </div>
              <div className="space-y-3">
                <div>
                  <h3 className="font-medium text-gray-900">Best Paper Award</h3>
                  <p className="text-sm text-gray-500">ICML 2022</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Outstanding Research Award</h3>
                  <p className="text-sm text-gray-500">Stanford University, 2021</p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;